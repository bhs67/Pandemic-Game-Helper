﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PandemicGame
{
    /// <summary>
    /// Interaction logic for dlgPlayerNumbers.xaml
    /// </summary>
    public partial class dlgPlayerNumbers : Window
    {
        //------------------------------
        #region ..... Global constants (#define) & Descriptors
        //------------------------------
        //------------------------------
        List<string> gliststImportantNumbers = new List<string>();
        string gstOkExitAnswer;
        //------------------------------
        //------------------------------
        #endregion ..... Global constants (#define) & Descriptors
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
        #region ..... Constructor / Destructor
        //------------------------------
        //------------------------------
        public dlgPlayerNumbers(List<string> liststImportantNumbers)
        {
            gliststImportantNumbers = liststImportantNumbers;
            InitializeComponent();
            WindowStyle = WindowStyle.None;
        }//dlgNumberOfPlayersAndEpidemics
        //------------------------------
        //------------------------------
        private void Window_ContentRendered(object sender, RoutedEventArgs e)
        {
            gTBxNumberOfPlayers.Text = "2";
            gTBxNumberOfEpidemics.Text = "5";
            gTBxNumberOfPlayers.Focus();
        }//Window_ContentRendered
        //------------------------------
        //------------------------------
        public string stDlgReturnValue 
        {
            get { return gstOkExitAnswer; }
        }//stDlgReturnValue
        //------------------------------
        //------------------------------
        #endregion ..... Constructor / Destructor
        //------------------------------
        //------------------------------
        #region ..... Buttons
        //------------------------------
        //------------------------------
        private void gBuExit_Click(object sender, RoutedEventArgs e)
        {
            gstOkExitAnswer = "exit";
            this.DialogResult = true;
            this.Close();
        }//gBuExit_Click
        //------------------------------
        //------------------------------
        private void gBuCaptureNumbers_Click(object sender, RoutedEventArgs e)
        {
            gstOkExitAnswer = "ok";
            bool boFlag = GetNumbers();
            if (boFlag == false)
                return;
            this.DialogResult = true;
            this.Close();
        }//gBuCaptureNumbers_Click
        //------------------------------
        //------------------------------
        #endregion ..... Buttons
        //------------------------------
        //------------------------------
        #region .....Text Boxes
        //------------------------------
        //------------------------------
        public bool GetNumbers()
        {
            int iNumberOfPlayers = -1;
            int iNumberOfEpidemics = -1;
            string stNumberOfPlayers = gTBxNumberOfPlayers.Text;
            string stNumberOfEpidemics = gTBxNumberOfEpidemics.Text;
            if (!boValidIntReturnsTrue(stNumberOfPlayers, out iNumberOfPlayers)) {
                dlgMessageBox dlgm = new dlgMessageBox("Number of Players", "An invalid entry", "Ok");
                dlgm.Owner = this;
                dlgm.ShowDialog();
                return false;
            }
            if (!boValidIntReturnsTrue(stNumberOfEpidemics, out iNumberOfEpidemics)) {
                dlgMessageBox dlgm = new dlgMessageBox("Number of Epidemics", "An invalid entry", "Ok");
                dlgm.Owner = this;
                dlgm.ShowDialog();
                return false;
            }
            gliststImportantNumbers.Clear();
            if (iNumberOfPlayers <  1)
                iNumberOfPlayers = 1;
            else if (iNumberOfPlayers > 4)
                iNumberOfPlayers = 4;
            gliststImportantNumbers.Add(iNumberOfPlayers.ToString());
            if (iNumberOfEpidemics < 1)
                iNumberOfEpidemics = 1;
            else if (iNumberOfEpidemics > 7)
                iNumberOfEpidemics = 7;
            gliststImportantNumbers.Add(iNumberOfEpidemics.ToString());
            return true;
        }//GetNumbers
         //------------------------------
         //------------------------------
        static public bool boValidIntReturnsTrue(string stValue, out int iNum)
        {
            //Returns true if the string is a valid int
            return int.TryParse(stValue, out iNum);
        }//boValidNumberReturnsTrue
        //------------------------------
        //------------------------------
        #endregion .....Text Boxes
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
    }//dlgPlayerNumbers : Window
}//PandemicGame
