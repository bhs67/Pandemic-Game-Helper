﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PandemicGame
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //------------------------------
        #region ..... Global Constants (#define) & Descriptors
        //------------------------------
        List<string> gliststImportantNumbers = new List<string>();
        double gdCardsInDeck = 0;
        int giNumberOfEpidemics = 0;
        int giCardsPerEpidemic = 0;

        List<string> gliststOriginalBlueCities = new List<string>();
        List<string> gliststOriginalYellowCities = new List<string>();
        List<string> gliststOriginalBlackCities = new List<string>();
        List<string> gliststOriginalRedCities = new List<string>();

        List<string> gliststInfectedBlueCities = new List<string>();
        List<string> gliststInfectedYellowCities = new List<string>();
        List<string> gliststInfectedBlackCities = new List<string>();
        List<string> gliststInfectedRedCities = new List<string>();

        List<string> gliststReshuffledList1st = new List<string>();
        List<string> gliststReshuffledList2nd = new List<string>();
        List<string> gliststReshuffledList3rd = new List<string>();
        List<string> gliststReshuffledList4th = new List<string>();
        List<string> gliststReshuffledList5th = new List<string>();
        List<string> gliststReshuffledList6th = new List<string>();
        List<string> gliststReshuffledList7th = new List<string>();

        List<string> gliststEpidemicCities = new List<string>();
        List<string> gliststResilientCities = new List<string>();

        List<string> gliststRemainingBlueCities = new List<string>();
        List<string> gliststRemainingYellowCities = new List<string>();
        List<string> gliststRemainingBlackCities = new List<string>();
        List<string> gliststRemainingRedCities = new List<string>();

        List<string> gliststOwnedBlueCities = new List<string>();
        List<string> gliststOwnedYellowCities = new List<string>();
        List<string> gliststOwnedBlackCities = new List<string>();
        List<string> gliststOwnedRedCities = new List<string>();

        List<string> gliststDiscardedBlueCities = new List<string>();
        List<string> gliststDiscardedYellowCities = new List<string>();
        List<string> gliststDiscardedBlackCities = new List<string>();
        List<string> gliststDiscardedRedCities = new List<string>();
        //------------------------------
        #endregion ..... Global Constants (#define) & Descriptors
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
        #region ..... Constructor / Destructor
        //------------------------------
        public MainWindow()
        {
            InitializeComponent();
        }//MainWindow
        //------------------------------
        //------------------------------
        private void Window_ContentRendered(object sender, EventArgs e)
        {
            string stRestart = RestartEverything();
            if (stRestart == "exit")
                this.Close();
        }//Window_ContentRendered
         //------------------------------
         //------------------------------
        private string RestartEverything()
        {
            gliststImportantNumbers.Clear();
            gdCardsInDeck = 0;
            giNumberOfEpidemics = 0;
            giCardsPerEpidemic = 0;

            RestartOriginalAndRemainingCities();
            gliststInfectedBlueCities.Clear();
            gliststInfectedYellowCities.Clear();
            gliststInfectedBlackCities.Clear();
            gliststInfectedRedCities.Clear();

            gliststReshuffledList1st.Clear();
            gliststReshuffledList2nd.Clear();
            gliststReshuffledList3rd.Clear();
            gliststReshuffledList4th.Clear();
            gliststReshuffledList5th.Clear();
            gliststReshuffledList6th.Clear();
            gliststReshuffledList7th.Clear();
            gliststEpidemicCities.Clear();
            gliststResilientCities.Clear();

            gliststDiscardedBlueCities.Clear();
            gliststDiscardedYellowCities.Clear();
            gliststDiscardedBlackCities.Clear();
            gliststDiscardedRedCities.Clear();

            gRBuRemainingBlueCities.IsChecked = false;
            gRBuRemainingYellowCities.IsChecked = false;
            gRBuRemainingBlackCities.IsChecked = false;
            gRBuRemainingRedCities.IsChecked = false;

            ClearRemainingCitiesListBoxes();

            //Add number of players and epidemics
            gliststImportantNumbers.Add("2");
            gliststImportantNumbers.Add("5");
            SetNumbersInTextBox();

            FillListBoxes();
            return "";
        }//RestartEverything
        //------------------------------
        //------------------------------
        #endregion ..... Constructor / Destructor
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
        #region ..... Buttons
        //------------------------------
        //------------------------------
        private void SetNumbersInTextBox()
        {
            gTBxNumberOfPlayers.Text = gliststImportantNumbers[0].ToString();
            gTBxNumberOfEpidemics.Text = gliststImportantNumbers[1].ToString();
            int iNumberOfPlayers = int.Parse(gliststImportantNumbers[0]);
            giNumberOfEpidemics = int.Parse(gliststImportantNumbers[1]);
            int iNumberOfCityCardsPerPlayer;
            switch (iNumberOfPlayers)
            {
                case 2:
                    iNumberOfCityCardsPerPlayer = 4;
                    break;
                case 3:
                    iNumberOfCityCardsPerPlayer = 3;
                    break;
                case 4:
                default:
                    iNumberOfCityCardsPerPlayer = 2;
                    break;
            }
            gdCardsInDeck = 48 + 5 + giNumberOfEpidemics - (iNumberOfPlayers * iNumberOfCityCardsPerPlayer);
            gTBxOriginalNumberOfCards.Text = gdCardsInDeck.ToString();
            double dCardsPerEpidemic =  Math.Round(gdCardsInDeck / giNumberOfEpidemics, 1);
            gTBxNumberOfCardsPerEpidemic.Text = (dCardsPerEpidemic).ToString();
            giCardsPerEpidemic = (int)Math.Truncate(dCardsPerEpidemic);
            MarkNumberOfEpidemicCards(0);
        }//SetNumbersInTextBox
        //------------------------------
        //------------------------------
        private void gBuFromInfectedToReshuffled_Click(object sender, RoutedEventArgs e)
        {
            int iIndex = -1;
            if (boRetrieveListBoxIndex(gLBxInfectedBlueCities, ref iIndex))
                HandleFromListBoxToInfectedListBoxChanges(gliststInfectedBlueCities, gliststReshuffledList1st, iIndex);
            else if (boRetrieveListBoxIndex(gLBxInfectedYellowCities, ref iIndex))
                HandleFromListBoxToInfectedListBoxChanges(gliststInfectedYellowCities, gliststReshuffledList1st, iIndex);
            else if (boRetrieveListBoxIndex(gLBxInfectedBlackCities, ref iIndex))
                HandleFromListBoxToInfectedListBoxChanges(gliststInfectedBlackCities, gliststReshuffledList1st, iIndex);
            else if (boRetrieveListBoxIndex(gLBxInfectedRedCities, ref iIndex))
                HandleFromListBoxToInfectedListBoxChanges(gliststInfectedRedCities, gliststReshuffledList1st, iIndex);
            else
            {
                dlgMessageBox dlgm = new dlgMessageBox("Reshuffled", "An Infected City was not selected.", "Ok");
                dlgm.Owner = this;
                dlgm.ShowDialog();
            }
        }//gBuFromInfectedToReshuffled_Click
        //------------------------------
        //------------------------------
        private void gBuReset_Click(object sender, RoutedEventArgs e)
        {
            dlgMessageBox dlgm = new dlgMessageBox("Restart", "Do you want to Reset.", "YesNo");
            dlgm.Owner = this;
            dlgm.ShowDialog();
            if (dlgm.DialogResult == true) {
                string gstOkYesNoAnswer = dlgm.stDlgReturnValue;
                if (gstOkYesNoAnswer == "Yes") {
                    string stRestart = RestartEverything();
                    if (stRestart == "exit")
                        this.Close();
                }
            }
            dlgm = new dlgMessageBox("Reset numbers", "Do you want to change the numbers?.", "YesNo");
            dlgm.Owner = this;
            dlgm.ShowDialog();
            if (dlgm.DialogResult == true) {
                string gstOkYesNoAnswer = dlgm.stDlgReturnValue;
                if (gstOkYesNoAnswer == "Yes") {
                    dlgPlayerNumbers dlg = new dlgPlayerNumbers(gliststImportantNumbers);
                    dlg.Owner = this;
                    dlg.ShowDialog();
                    if (dlg.DialogResult == true) {
                        if (dlg.stDlgReturnValue == "exit") {
                            this.Close();
                        }
                        else
                            SetNumbersInTextBox();
                    }
                }
            }
        }//gBuReset_Click
        //------------------------------
        //------------------------------
        private void gBuExit_Click(object sender, RoutedEventArgs e)
        {
            dlgMessageBox dlgm = new dlgMessageBox("Exit", "Do you want to Exit.", "YesNo");
            dlgm.Owner = this;
            dlgm.ShowDialog();
            if (dlgm.DialogResult == true) {
                string gstOkYesNoAnswer = dlgm
                    .stDlgReturnValue;
                if (gstOkYesNoAnswer == "Yes")
                    this.Close();
            }
        }//gBuExit_Click
        //------------------------------
        //------------------------------
        private void gBUCitiesRemaining_Click(object sender, RoutedEventArgs e)
        {
            dlgRemaining dlg = new dlgRemaining(gliststRemainingBlueCities,
                                                                            gliststRemainingYellowCities,
                                                                            gliststRemainingBlackCities,
                                                                            gliststRemainingRedCities,
                                                                            gliststOwnedBlueCities,
                                                                            gliststOwnedYellowCities,
                                                                            gliststOwnedBlackCities,
                                                                            gliststOwnedRedCities,
                                                                            gliststDiscardedBlueCities,
                                                                            gliststDiscardedYellowCities,
                                                                            gliststDiscardedBlackCities,
                                                                            gliststDiscardedRedCities);
            dlg.Owner = this;
            dlg.ShowDialog();
            ClearRemainingCitiesListBoxes();
            FillListBoxes();
        }//gBUCitiesRemaining_Click
         //------------------------------
        //------------------------------
        private void gBuEpidemic_Click(object sender, RoutedEventArgs e)
        {
            List<string> liststCityIndex = new List<string>();
            if (boIdentifyEpidemicCity(liststCityIndex)) {
                dlgMessageBox dlgm = new dlgMessageBox("Epidemic", "for " + liststCityIndex[0] + "?", "YesNo");
                dlgm.Owner = this;
                dlgm.ShowDialog();
                if (dlgm.DialogResult == true) {
                    string gstOkYesNoAnswer = dlgm.stDlgReturnValue;
                    if (gstOkYesNoAnswer == "Yes")  {
                        int iIndex = int.Parse(liststCityIndex[1]);
                        switch (liststCityIndex[2]) {
                            case "blue":
                                HandleEpidemicListBoxChanges(gliststOriginalBlueCities, iIndex);
                                break;
                            case "yellow":
                                HandleEpidemicListBoxChanges(gliststOriginalYellowCities, iIndex);
                                break;
                            case "black":
                                HandleEpidemicListBoxChanges(gliststOriginalBlackCities, iIndex);
                                break;
                            case "red":
                                HandleEpidemicListBoxChanges(gliststOriginalRedCities, iIndex);
                                break;
                        }
                        FillListBoxes();
                        MarkNumberOfEpidemicCards(gliststEpidemicCities.Count());
                    }
                }
            }
        }//gBuEpidemic_Click
        //------------------------------
        //------------------------------
        private bool boIdentifyEpidemicCity(List<string> liststCityIndex)
        {
            int iIndex = -1;
            if (boRetrieveListBoxIndex(gLBxOriginalBlueCities, ref iIndex)) {
                liststCityIndex.Add(gliststOriginalBlueCities[iIndex]);
                liststCityIndex.Add(iIndex.ToString());
                liststCityIndex.Add("blue");
            }
            else if (boRetrieveListBoxIndex(gLBxOriginalYellowCities, ref iIndex)) {
                liststCityIndex.Add(gliststOriginalYellowCities[iIndex]);
                liststCityIndex.Add(iIndex.ToString());
                liststCityIndex.Add("yellow");
            }
            else if (boRetrieveListBoxIndex(gLBxOriginalBlackCities, ref iIndex)) {
                liststCityIndex.Add(gliststOriginalBlackCities[iIndex]);
                liststCityIndex.Add(iIndex.ToString());
                liststCityIndex.Add("black");
            }
            else if (boRetrieveListBoxIndex(gLBxOriginalRedCities, ref iIndex)) {
                liststCityIndex.Add(gliststOriginalRedCities[iIndex]);
                liststCityIndex.Add(iIndex.ToString());
                liststCityIndex.Add("red");
            }
            else {
                dlgMessageBox dlgm = new dlgMessageBox("Epidemic", "An Original City was not selected.", "Ok");
                dlgm.Owner = this;
                dlgm.ShowDialog();
                return false;
            }
            return true;
        }//boIdentifyEpidemicCity
         //------------------------------
         //------------------------------
        private void HandleEpidemicListBoxChanges(List<string> liststOriginalCity, int iIndex)
        {
            //Copy OriginalColorCity to Epidemic
            gliststEpidemicCities.Add(liststOriginalCity[iIndex]);

            List<string> gliststInfectedCities = new List<string>();
            //Copy OriginalColorCity to temporary InfectedCity
            gliststInfectedCities.Add(liststOriginalCity[iIndex]);
            //Remove OriginalColorCity
            liststOriginalCity.RemoveAt(iIndex);

            //Add colored infected cities
            AddListToList(gliststInfectedBlueCities, gliststInfectedCities);
            gliststInfectedBlueCities.Clear();
            AddListToList(gliststInfectedYellowCities, gliststInfectedCities);
            gliststInfectedYellowCities.Clear();
            AddListToList(gliststInfectedBlackCities, gliststInfectedCities);
            gliststInfectedBlackCities.Clear();
            AddListToList(gliststInfectedRedCities, gliststInfectedCities);
            gliststInfectedRedCities.Clear();

            //Copy all reshuffled infected cities, then clear
            CopyListToList(gliststReshuffledList6th, gliststReshuffledList7th);
            CopyListToList(gliststReshuffledList5th, gliststReshuffledList6th);
            CopyListToList(gliststReshuffledList4th, gliststReshuffledList5th);
            CopyListToList(gliststReshuffledList3rd, gliststReshuffledList4th);
            CopyListToList(gliststReshuffledList2nd, gliststReshuffledList3rd);
            CopyListToList(gliststReshuffledList1st, gliststReshuffledList2nd);
            CopyListToList(gliststInfectedCities, gliststReshuffledList1st);
            gliststInfectedCities.Clear();
        }//HandleEpidemicListBoxChanges
         //------------------------------
         //------------------------------
        private void gBuResilient_Click(object sender, RoutedEventArgs e)
        {
            List<string> liststCityIndex = new List<string>();
            if (boIdentifyResilientCity(liststCityIndex))
            {
                dlgMessageBox dlgm = new dlgMessageBox("Resilient", "for " + liststCityIndex[0] + "?", "YesNo");
                dlgm.Owner = this;
                dlgm.ShowDialog();
                if (dlgm.DialogResult == true) {
                    string gstOkYesNoAnswer = dlgm.stDlgReturnValue;
                    if (gstOkYesNoAnswer == "Yes")
                    {
                        int iIndex = int.Parse(liststCityIndex[1]);
                        switch (liststCityIndex[2])
                        {
                            case "blue":
                                HandleFromListBoxToInfectedListBoxChanges(gliststInfectedBlueCities, gliststResilientCities, iIndex);
                                break;
                            case "yellow":
                                HandleFromListBoxToInfectedListBoxChanges(gliststInfectedYellowCities, gliststResilientCities, iIndex);
                                break;
                            case "black":
                                HandleFromListBoxToInfectedListBoxChanges(gliststInfectedBlackCities, gliststResilientCities, iIndex);
                                break;
                            case "red":
                                HandleFromListBoxToInfectedListBoxChanges(gliststInfectedRedCities, gliststResilientCities, iIndex);
                                break;
                        }
                        FillListBoxes();
                        MarkNumberOfEpidemicCards(gliststEpidemicCities.Count());
                    }
                }
            }
        }//gBuResilient_Click
        //------------------------------
        //------------------------------
        private bool boIdentifyResilientCity(List<string> liststCityIndex)
        {
            int iIndex = -1;
            if (boRetrieveListBoxIndex(gLBxInfectedBlueCities, ref iIndex)) {
                liststCityIndex.Add(gliststInfectedBlueCities[iIndex]);
                liststCityIndex.Add(iIndex.ToString());
                liststCityIndex.Add("blue");
            }
            else if (boRetrieveListBoxIndex(gLBxInfectedYellowCities, ref iIndex)) {
                liststCityIndex.Add(gliststInfectedYellowCities[iIndex]);
                liststCityIndex.Add(iIndex.ToString());
                liststCityIndex.Add("yellow");
            }
            else if (boRetrieveListBoxIndex(gLBxInfectedBlackCities, ref iIndex)) {
                liststCityIndex.Add(gliststInfectedBlackCities[iIndex]);
                liststCityIndex.Add(iIndex.ToString());
                liststCityIndex.Add("black");
            }
            else if (boRetrieveListBoxIndex(gLBxInfectedRedCities, ref iIndex)) {
                liststCityIndex.Add(gliststInfectedRedCities[iIndex]);
                liststCityIndex.Add(iIndex.ToString());
                liststCityIndex.Add("red");
            }
            else {
                dlgMessageBox dlgm = new dlgMessageBox("Resilient", "An Infected City was not selected.", "Ok");
                dlgm.Owner = this;
                dlgm.ShowDialog();
                return false;
            }
            return true;
        }//boIdentifyResilientCity
         //------------------------------
         //------------------------------
        private void HandleFromListBoxToInfectedListBoxChanges(List<string> liststFrom, List<string> liststTo, int iIndex)
        {
            liststTo.Add(liststFrom[iIndex]);
            liststFrom.RemoveAt(iIndex);
            FillListBoxes();
        }//HandleFromListBoxToInfectedListBoxChanges
        //------------------------------
        //------------------------------
        #endregion ..... Buttons
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
        #region ..... Buttons / Mouse ... Original / Infected
        //------------------------------
        //------------------------------
        private void gLBxOriginalBlueCitiesToInfectedCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MoveFromListBoxListStringToListString(gLBxOriginalBlueCities, gliststOriginalBlueCities, gliststInfectedBlueCities);
        }//gLBxOriginalBlueCitiesToInfectedCities_MouseDoubleClick
        //------------------------------
        //------------------------------
        private void gLBxOriginalYellowCitiesToInfectedCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MoveFromListBoxListStringToListString(gLBxOriginalYellowCities, gliststOriginalYellowCities, gliststInfectedYellowCities);
        }//gLBxOriginalYellowCitiesToInfectedCities_MouseDoubleClick
        //------------------------------
        //------------------------------
        private void gLBxOriginalBlackCitiesToInfectedCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MoveFromListBoxListStringToListString(gLBxOriginalBlackCities, gliststOriginalBlackCities, gliststInfectedBlackCities);
        }//gLBxOriginalBlackCitiesToInfectedCities_MouseDoubleClick
        //------------------------------
        //------------------------------
        private void gLBxOriginalRedCitiesToInfectedCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MoveFromListBoxListStringToListString(gLBxOriginalRedCities, gliststOriginalRedCities, gliststInfectedRedCities);
        }//gLBxOriginalRedCitiesToInfectedCities_MouseDoubleClick
        //------------------------------
        //------------------------------
        private void gLBxInfectedBlueCitiesToOriginalBlueCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MoveFromListBoxListStringToListString(gLBxInfectedBlueCities, gliststInfectedBlueCities, gliststOriginalBlueCities);
        }//gLBxInfectedBlueCitiesToOriginalBlueCities_MouseDoubleClick
        //------------------------------
        //------------------------------
        private void gLBxInfectedYellowCitiesToOriginaYellowCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MoveFromListBoxListStringToListString(gLBxInfectedYellowCities, gliststInfectedYellowCities, gliststOriginalYellowCities);
        }//gLBxInfectedYellowCitiesToOriginaYellowCities_MouseDoubleClick
        //------------------------------
        //------------------------------
        private void gLBxInfectedBlackCitiesToOriginalBlackCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MoveFromListBoxListStringToListString(gLBxInfectedBlackCities, gliststInfectedBlackCities, gliststOriginalBlackCities);
        }//gLBxInfectedBlackCitiesToOriginalBlackCities_MouseDoubleClick
        //------------------------------
        //------------------------------
        private void gLBxInfectedRedCitiesToOriginalRedCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MoveFromListBoxListStringToListString(gLBxInfectedRedCities, gliststInfectedRedCities, gliststOriginalRedCities);
        }//gLBxInfectedRedCitiesToOriginalRedCities_MouseDoubleClick
        //------------------------------
        //------------------------------
        #endregion ..... Buttons / Mouse ... Original / Infected
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
        #region ..... Buttons / Mouse ... Infected / Reshuffled
        //------------------------------
        //------------------------------
        private void gLBxReshuffledList1stToInfectedCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var selectedCity = gLBxReshuffledList1st.SelectedItem;
            if (selectedCity != null) {
                int iIndex = -1;
                if (gliststReshuffledList1st.Count != 0) {
                    if (boRetrieveListBoxIndex(gLBxReshuffledList1st, ref iIndex)) {
                        if (boRetrieveListBoxIndex(gLBxReshuffledList1st, ref iIndex)) {
                            string stInfectedCity = gliststReshuffledList1st[iIndex];
                            if (stInfectedCity.Contains("blue"))
                                gliststInfectedBlueCities.Add(gliststReshuffledList1st[iIndex]);
                            else if (stInfectedCity.Contains("yellow"))
                                gliststInfectedYellowCities.Add(gliststReshuffledList1st[iIndex]);
                            else if (stInfectedCity.Contains("black"))
                                gliststInfectedBlackCities.Add(gliststReshuffledList1st[iIndex]);
                            else if (stInfectedCity.Contains("red"))
                                gliststInfectedRedCities.Add(gliststReshuffledList1st[iIndex]);
                        }
                        gliststReshuffledList1st.RemoveAt(iIndex);
                        if (gliststReshuffledList1st.Count == 0) {
                            CopyListToList(gliststReshuffledList2nd, gliststReshuffledList1st);
                            CopyListToList(gliststReshuffledList3rd, gliststReshuffledList2nd);
                            CopyListToList(gliststReshuffledList4th, gliststReshuffledList3rd);
                            CopyListToList(gliststReshuffledList5th, gliststReshuffledList4th);
                            CopyListToList(gliststReshuffledList6th, gliststReshuffledList5th);
                            CopyListToList(gliststReshuffledList7th, gliststReshuffledList6th);
                        }
                        FillListBoxes();
                    }
                }
            }
        }//gLBxReshuffledList1stToInfectedCities_MouseDoubleClick
         //------------------------------
         //------------------------------
        private void gLBxReshuffledList2ndToReshuffledCitiesList1st_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var selectedCity = gLBxReshuffledList2nd.SelectedItem;
            if (selectedCity != null) {
                int iIndex = -1;
                if (boRetrieveListBoxIndex(gLBxReshuffledList2nd, ref iIndex)) {
                    gliststReshuffledList1st.Add(gliststReshuffledList2nd[iIndex]);
                    gliststReshuffledList2nd.RemoveAt(iIndex);
                    FillListBoxes();
                }
            }
        }//gLBxReshuffledList2ndToReshuffledCitiesList1st_MouseDoubleClick
         //------------------------------
         //------------------------------
        #endregion ..... Buttons / Mouse ... Infected / Reshuffled
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
        #region ..... List Boxes
        //------------------------------
        //------------------------------
        public void FillListBoxes()
        {
            gliststOriginalBlueCities.Sort();
            FillListBox(gLBxOriginalBlueCities, gliststOriginalBlueCities);
            gliststOriginalYellowCities.Sort();
            FillListBox(gLBxOriginalYellowCities, gliststOriginalYellowCities);
            gliststOriginalBlackCities.Sort();
            FillListBox(gLBxOriginalBlackCities, gliststOriginalBlackCities);
            gliststOriginalRedCities.Sort();
            FillListBox(gLBxOriginalRedCities, gliststOriginalRedCities);

            gliststInfectedBlueCities.Sort();
            FillListBox(gLBxInfectedBlueCities, gliststInfectedBlueCities);
            gliststInfectedYellowCities.Sort();
            FillListBox(gLBxInfectedYellowCities, gliststInfectedYellowCities);
            gliststInfectedBlackCities.Sort();
            FillListBox(gLBxInfectedBlackCities, gliststInfectedBlackCities);
            gliststInfectedRedCities.Sort();
            FillListBox(gLBxInfectedRedCities, gliststInfectedRedCities);

           gliststReshuffledList1st.Sort();
            FillListBox(gLBxReshuffledList1st, gliststReshuffledList1st);
            
            gliststReshuffledList2nd.Sort();
            FillListBox(gLBxReshuffledList2nd, gliststReshuffledList2nd);

            gliststReshuffledList3rd.Sort();
            FillListBox(gLBxReshuffledList3rd, gliststReshuffledList3rd);
            gliststReshuffledList4th.Sort();
            FillListBox(gLBxReshuffledList4th, gliststReshuffledList4th);
            gliststReshuffledList5th.Sort();
            FillListBox(gLBxReshuffledList5th, gliststReshuffledList5th);
            gliststReshuffledList6th.Sort();
            FillListBox(gLBxReshuffledList6th, gliststReshuffledList6th);
            gliststReshuffledList7th.Sort();
            FillListBox(gLBxReshuffledList7th, gliststReshuffledList7th);

            FillListBox(gLBxEpidemicCities, gliststEpidemicCities);
            FillListBox(gLBxResilient, gliststResilientCities);
        }//FillListBoxes
        //------------------------------
        //------------------------------
        public void FillListBox(ListBox LBx, List<string> liststX)
        {
            LBx.Items.Clear();
            if (liststX.Count > 0) {
                string stName = liststX[0];
                LBx.Items.Add(stName);
                for (int iii = 1; iii < liststX.Count; iii++) {
                    stName = liststX[iii];
                    LBx.Items.Add(stName);
                }
            }
        }//FillListBox
        //------------------------------
        //------------------------------
        private void MoveFromListBoxListStringToListString(ListBox LBx, List<string> ListstFrom, List<string> ListstTo)
        {
            var selectedCity = LBx.SelectedItem;
            if (selectedCity != null) {
                int iIndex = -1;
                if (boRetrieveListBoxIndex(LBx, ref iIndex)) {
                    ListstTo.Add(ListstFrom[iIndex]);
                    ListstFrom.RemoveAt(iIndex);
                    FillListBoxes();
                }
            }
        }//MoveFromListBoxListStringToListString
        //------------------------------
        //------------------------------
        public bool boRetrieveListBoxIndex(ListBox LBx, ref int iIndex)
        {
            bool boItemIsSelectedFlag = false;
            iIndex = LBx.SelectedIndex;
            if (iIndex >= 0)
                boItemIsSelectedFlag = true;
            return boItemIsSelectedFlag;
        }//iLbxIndex
         //------------------------------
         //------------------------------
        private void gLBxOriginalBlueCities_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            gLBxOriginalYellowCities.UnselectAll();
            gLBxOriginalBlackCities.UnselectAll();
            gLBxOriginalRedCities.UnselectAll();
        }//gLBxOriginalBlueCities_PreviewMouseLeftButtonDown
         //------------------------------
         //------------------------------
        private void gLBxOriginalYellowCities_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            gLBxOriginalBlueCities.UnselectAll();
            gLBxOriginalBlackCities.UnselectAll();
            gLBxOriginalRedCities.UnselectAll();
        }//gLBxOriginalYellowCities_PreviewMouseLeftButtonDown
         //------------------------------
         //------------------------------
        private void gLBxOriginalBlackCities_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            gLBxOriginalBlueCities.UnselectAll();
            gLBxOriginalYellowCities.UnselectAll();
            gLBxOriginalRedCities.UnselectAll();
        }//gLBxOriginalBlackCities_PreviewMouseLeftButtonDown
         //------------------------------
         //------------------------------
        private void gLBxOriginalRedCities_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            gLBxOriginalBlueCities.UnselectAll();
            gLBxOriginalYellowCities.UnselectAll();
            gLBxOriginalBlackCities.UnselectAll();
        }//gLBxOriginalRedCities_PreviewMouseLeftButtonDown
        //------------------------------
        //------------------------------
        #endregion ..... List Boxes
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
        #region ..... Check Boxes
        //------------------------------
        //------------------------------
        #endregion ..... Check Boxes
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
        #region ..... Radio Buttons
        //------------------------------
        //------------------------------
        private void gRBuRemainingBlueCities_Click(object sender, RoutedEventArgs e)
        {
            ClearRemainingCitiesListBoxes();
            this.gLBxOwnedBlueCities.Visibility = System.Windows.Visibility.Visible;
            this.gLBxRemainingBlueCities.Visibility = System.Windows.Visibility.Visible;
            this.gLBxOwnedYellowCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxRemainingYellowCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxOwnedBlackCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxRemainingBlackCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxOwnedRedCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxRemainingRedCities.Visibility = System.Windows.Visibility.Collapsed;
            gliststRemainingBlueCities.Sort();
            FillListBox(gLBxOwnedBlueCities, gliststOwnedBlueCities);
            FillListBox(gLBxRemainingBlueCities, gliststRemainingBlueCities);
        }//gRBuRemainingBlueCities_Click
        //------------------------------
        //------------------------------
        private void gRBuRemainingYellowCities_Click(object sender, RoutedEventArgs e)
        {
            ClearRemainingCitiesListBoxes();
            this.gLBxOwnedBlueCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxRemainingBlueCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxOwnedYellowCities.Visibility = System.Windows.Visibility.Visible;
            this.gLBxRemainingYellowCities.Visibility = System.Windows.Visibility.Visible;
            this.gLBxOwnedBlackCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxRemainingBlackCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxOwnedRedCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxRemainingRedCities.Visibility = System.Windows.Visibility.Collapsed;
            gliststRemainingYellowCities.Sort();
            FillListBox(gLBxOwnedYellowCities, gliststOwnedYellowCities);
            FillListBox(gLBxRemainingYellowCities, gliststRemainingYellowCities);
        }//gRBuRemainingYellowCities_Click
        //------------------------------
        //------------------------------
        private void gRBuRemainingBlackCities_Click(object sender, RoutedEventArgs e)
        {
            ClearRemainingCitiesListBoxes();
            this.gLBxOwnedBlueCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxRemainingBlueCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxOwnedYellowCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxRemainingYellowCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxOwnedBlackCities.Visibility = System.Windows.Visibility.Visible;
            this.gLBxRemainingBlackCities.Visibility = System.Windows.Visibility.Visible;
            this.gLBxOwnedRedCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxRemainingRedCities.Visibility = System.Windows.Visibility.Collapsed;
            gliststRemainingBlackCities.Sort();
            FillListBox(gLBxOwnedBlackCities, gliststOwnedBlackCities);
            FillListBox(gLBxRemainingBlackCities, gliststRemainingBlackCities);
        }//gRBuRemainingBlackCities_Click
        //------------------------------
        //------------------------------
        private void gRBuRemainingRedCities_Click(object sender, RoutedEventArgs e)
        {
            ClearRemainingCitiesListBoxes();
            this.gLBxOwnedBlueCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxRemainingBlueCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxOwnedYellowCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxRemainingYellowCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxOwnedBlackCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxRemainingBlackCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxOwnedRedCities.Visibility = System.Windows.Visibility.Visible;
            this.gLBxRemainingRedCities.Visibility = System.Windows.Visibility.Visible;
            gliststRemainingRedCities.Sort();
            FillListBox(gLBxOwnedRedCities, gliststOwnedRedCities);
            FillListBox(gLBxRemainingRedCities, gliststRemainingRedCities);
        }//gRBuRemainingRedCities_Click
        //------------------------------
        //------------------------------
        private void ClearRemainingCitiesListBoxes()
        {
            gLBxOwnedBlueCities.Items.Clear();
            gLBxOwnedYellowCities.Items.Clear();
            gLBxOwnedBlackCities.Items.Clear();
            gLBxOwnedRedCities.Items.Clear();

            gLBxRemainingBlueCities.Items.Clear();
            gLBxRemainingYellowCities.Items.Clear();
            gLBxRemainingBlackCities.Items.Clear();
            gLBxRemainingRedCities.Items.Clear();
            CollapseOwnedAndRemainingCities();
        }//ClearRemainingCitiesListBoxes
        //------------------------------
        //------------------------------
        private void gRBuEradicatedBlueCities_Click(object sender, RoutedEventArgs e)
        {
            dlgMessageBox dlgm = new dlgMessageBox("", "Did you Eradicate Blue?", "YesNo");
            dlgm.Owner = this;
            dlgm.ShowDialog();
            if (dlgm.DialogResult == true)
            {
                string gstOkYesNoAnswer = dlgm.stDlgReturnValue;
                if (gstOkYesNoAnswer == "Yes")
                {
                    gliststRemainingBlueCities.Clear();
                    gliststDiscardedBlueCities.Clear();
                    CollapseOwnedAndRemainingCities();
                }
            }
        }//gRBuEradicatedBlueCities_Click
        //------------------------------
        //------------------------------
        private void gRBuEradicatedYellowCities_Click(object sender, RoutedEventArgs e)
        {
            dlgMessageBox dlgm = new dlgMessageBox("", "Did you Eradicate Yellow?", "YesNo");
            dlgm.Owner = this;
            dlgm.ShowDialog();
            if (dlgm.DialogResult == true)
            {
                string gstOkYesNoAnswer = dlgm.stDlgReturnValue;
                if (gstOkYesNoAnswer == "Yes")
                {
                    gliststRemainingYellowCities.Clear();
                    gliststDiscardedYellowCities.Clear();
                    CollapseOwnedAndRemainingCities();
                }
            }
        }//gRBuEradicatedYellowCities_Click
        //------------------------------
        //------------------------------
        private void gRBuEradicatedBlackCities_Click(object sender, RoutedEventArgs e)
        {
            dlgMessageBox dlgm = new dlgMessageBox("", "Did you Eradicate Black?", "YesNo");
            dlgm.Owner = this;
            dlgm.ShowDialog();
            if (dlgm.DialogResult == true)
            {
                string gstOkYesNoAnswer = dlgm.stDlgReturnValue;
                if (gstOkYesNoAnswer == "Yes")
                {
                    gliststRemainingBlackCities.Clear();
                    gliststDiscardedBlackCities.Clear();
                    CollapseOwnedAndRemainingCities();
                }
            }
        }//gRBuEradicatedYellowCities_Click
        //------------------------------
        //------------------------------
        private void gRBuEradicatedRedCities_Click(object sender, RoutedEventArgs e)
        {
            dlgMessageBox dlgm = new dlgMessageBox("", "Did you Eradicate Red?", "YesNo");
            dlgm.Owner = this;
            dlgm.ShowDialog();
            if (dlgm.DialogResult == true)
            {
                string gstOkYesNoAnswer = dlgm.stDlgReturnValue;
                if (gstOkYesNoAnswer == "Yes")
                {
                    gliststRemainingRedCities.Clear();
                    gliststDiscardedRedCities.Clear();
                    CollapseOwnedAndRemainingCities();
                }
            }
        }//gRBuEradicatedRedCities_Click
        //------------------------------
        //------------------------------
        private void CollapseOwnedAndRemainingCities()
        {
            this.gLBxOwnedBlueCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxOwnedYellowCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxOwnedBlackCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxOwnedRedCities.Visibility = System.Windows.Visibility.Collapsed;

            this.gLBxRemainingBlueCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxRemainingYellowCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxRemainingBlackCities.Visibility = System.Windows.Visibility.Collapsed;
            this.gLBxRemainingRedCities.Visibility = System.Windows.Visibility.Collapsed;
        }//CollapseOwnedAndRemainingCities
        //------------------------------
        //------------------------------
        #endregion ..... Radio Buttons
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
        #region ..... General
        //------------------------------
        //------------------------------
        private void RestartOriginalAndRemainingCities()
        {
            gliststOriginalBlueCities.Clear();
            gliststOriginalYellowCities.Clear();
            gliststOriginalBlackCities.Clear();
            gliststOriginalRedCities.Clear();

            gliststRemainingBlueCities.Clear();
            gliststRemainingYellowCities.Clear();
            gliststRemainingBlackCities.Clear();
            gliststRemainingRedCities.Clear();
            { 
                gliststOriginalBlueCities.Add("Atlanta - blue");
                gliststOriginalBlueCities.Add("Chicago - blue");
                gliststOriginalBlueCities.Add("Essen - blue");
                gliststOriginalBlueCities.Add("London - blue");
                gliststOriginalBlueCities.Add("Madrid - blue");
                gliststOriginalBlueCities.Add("Milan - blue");
                gliststOriginalBlueCities.Add("Montreal - blue");
                gliststOriginalBlueCities.Add("New York - blue");
                gliststOriginalBlueCities.Add("Paris - blue");
                gliststOriginalBlueCities.Add("San Francisco - blue");
                gliststOriginalBlueCities.Add("St Petersburg - blue");
                gliststOriginalBlueCities.Add("Washington - blue");

                gliststOriginalYellowCities.Add("Bogota - yellow");
                gliststOriginalYellowCities.Add("Buenos Aires - yellow");
                gliststOriginalYellowCities.Add("Johannesburg - yellow");
                gliststOriginalYellowCities.Add("Khartoum - yellow");
                gliststOriginalYellowCities.Add("Kinshasa - yellow");
                gliststOriginalYellowCities.Add("Lagos - yellow");
                gliststOriginalYellowCities.Add("Lima - yellow");
                gliststOriginalYellowCities.Add("Los Angeles - yellow");
                gliststOriginalYellowCities.Add("Mexico City - yellow");
                gliststOriginalYellowCities.Add("Miami - yellow");
                gliststOriginalYellowCities.Add("Santiago - yellow");
                gliststOriginalYellowCities.Add("Sao Paulo - yellow");

                gliststOriginalBlackCities.Add("Algiers - black");
                gliststOriginalBlackCities.Add("Baghdad - black");
                gliststOriginalBlackCities.Add("Cairo - black");
                gliststOriginalBlackCities.Add("Chennai - black");
                gliststOriginalBlackCities.Add("Delhi - black");
                gliststOriginalBlackCities.Add("Istanbul - black");
                gliststOriginalBlackCities.Add("Karachi - black");
                gliststOriginalBlackCities.Add("Kolkata - black");
                gliststOriginalBlackCities.Add("Moscow - black");
                gliststOriginalBlackCities.Add("Mumbai - black");
                gliststOriginalBlackCities.Add("Riyadh - black");
                gliststOriginalBlackCities.Add("Tehran - black");

                gliststOriginalRedCities.Add("Bankok - red");
                gliststOriginalRedCities.Add("Beijing - red");
                gliststOriginalRedCities.Add("Ho Chi Minh - red");
                gliststOriginalRedCities.Add("Hong Kong - red");
                gliststOriginalRedCities.Add("Jakarta - red");
                gliststOriginalRedCities.Add("Manila - red");
                gliststOriginalRedCities.Add("Osaka - red");
                gliststOriginalRedCities.Add("Seoul - red");
                gliststOriginalRedCities.Add("Shanghai - red");
                gliststOriginalRedCities.Add("Sydney - red");
                gliststOriginalRedCities.Add("Taipei - red");
                gliststOriginalRedCities.Add("Tokyo - red");
            }

            CopyListToList(gliststOriginalBlueCities, gliststRemainingBlueCities);
            CopyListToList(gliststOriginalYellowCities, gliststRemainingYellowCities);
            CopyListToList(gliststOriginalBlackCities, gliststRemainingBlackCities);
            CopyListToList(gliststOriginalRedCities, gliststRemainingRedCities);

        }//RestartOriginalAndRemainingCities
         //------------------------------
         //------------------------------
        public void CopyListToList(List<string> FromList, List<string> ToList)
        {
            ToList.Clear();
            int iCount = FromList.Count;
            for (int ii = 0; ii < iCount; ii++) {
                ToList.Add(FromList[iCount - 1 - ii]);
            }
        }//CopyListToList
        //------------------------------
        //------------------------------
        public void AddListToList(List<string> FromList, List<string> ToList)
        {
            int iCount = FromList.Count;
            for (int ii = 0; ii < iCount; ii++) {
                ToList.Add(FromList[iCount - 1 - ii]);
            }
        }//AddListToList
        //------------------------------
        //------------------------------
        public void MarkNumberOfEpidemicCards(int iIndex)
        {
            List<string> gliststEpidemicSequence = new List<string>();
            gLBxEpidemicSequence.Items.Clear();
            for (int ii = 0; ii < giNumberOfEpidemics; ii++) {
                string stCardsPerEpidemicMax = (gdCardsInDeck - giCardsPerEpidemic * (ii)).ToString();
                string stCardsPerEpidemicMin = (gdCardsInDeck - giCardsPerEpidemic * (ii + 1)).ToString();
                if (stCardsPerEpidemicMin == "0")
                    stCardsPerEpidemicMin = "00";
                gliststEpidemicSequence.Add(stCardsPerEpidemicMin + " to " + stCardsPerEpidemicMax);
                gLBxEpidemicSequence.Items.Add(gliststEpidemicSequence[ii]);            
            }          
            gLBxEpidemicSequence.SelectedIndex = iIndex;
        }//MarkNumberOfEpidemicCards
        //------------------------------
        //------------------------------
        #endregion ..... General
        //------------------------------
    }//MainWindow : Window
}//PandemicGame
