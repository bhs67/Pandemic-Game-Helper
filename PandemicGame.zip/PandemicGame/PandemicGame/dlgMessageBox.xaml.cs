﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PandemicGame
{
    /// <summary>
    /// Interaction logic for dlgMessageBox.xaml
    /// </summary>
    public partial class dlgMessageBox : Window
    {
        //------------------------------
        #region ..... Global constants (#define) & Descriptors
        //------------------------------
        string gstTitle;
        string gstMessage;
        string gstOkYesNoButtons;
        string gstOkYesNoAnswer;
        //------------------------------
        #endregion ..... Global constants (#define) & Descriptors
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
        #region ..... Constructor / Destructor
        //------------------------------
        //------------------------------
        public dlgMessageBox(string stTitle, string stMessage, string stOkYesNoButtons)
        {
            InitializeComponent();
            gstTitle = stTitle;
            gstMessage = stMessage;
            gstOkYesNoButtons = stOkYesNoButtons;
            WindowStyle = WindowStyle.None;
        }//dlgMessageBox
        //------------------------------
        //------------------------------
        private void Window_ContentRendered(object sender, RoutedEventArgs e)
        {
            gLBlTitle.Content = gstTitle;
            gLBlMessage.Content = gstMessage;
            if (gstOkYesNoButtons == "Ok") {
                this.gBuOk.Visibility = System.Windows.Visibility.Visible;
                this.gBuYes.Visibility = System.Windows.Visibility.Collapsed;
                this.gBuNo.Visibility = System.Windows.Visibility.Collapsed;                
            }
            else if (gstOkYesNoButtons == "YesNo") {
                this.gBuOk.Visibility = System.Windows.Visibility.Collapsed;
                this.gBuYes.Visibility = System.Windows.Visibility.Visible;
                this.gBuNo.Visibility = System.Windows.Visibility.Visible;
            }
        }//Window_ContentRendered
        //------------------------------
        //------------------------------
        public string stDlgReturnValue 
        {
            get { return gstOkYesNoAnswer; }
        }//listliststDlgReturnValues
        //------------------------------
        //------------------------------
        #endregion ..... Constructor / Destructor
        //------------------------------
        //------------------------------
        #region ..... Buttons
        //------------------------------
        //------------------------------
        private void gBuYes_Click(object sender, RoutedEventArgs e)
        {
            gstOkYesNoAnswer = "Yes";
            this.DialogResult = true;
            this.Close();
        }//gBuYes_Click
        //------------------------------
        //------------------------------
        private void gBuOk_Click(object sender, RoutedEventArgs e)
        {
            gstOkYesNoAnswer = "Ok";
            this.DialogResult = true;
            this.Close();
        }//gBuOk_Click
        //------------------------------
        //------------------------------
        private void gBuNo_Click(object sender, RoutedEventArgs e)
        {
            gstOkYesNoAnswer = "No";
            this.DialogResult = true;
            this.Close();
        }//gBu_Click
        //------------------------------
        //------------------------------
        #endregion ..... Buttons
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
    }//dlgMessageBox : Window
}//PandemicGame
