﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PandemicGame
{
    /// <summary>
    /// Interaction logic for dlgRemaining.xaml
    /// </summary>
    public partial class dlgRemaining : Window
    {
        //------------------------------
        #region ..... Global Constants (#define) & Descriptors
        //------------------------------
        //------------------------------
        List<string> gliststRemainingBlueCities = new List<string>();
        List<string> gliststRemainingYellowCities = new List<string>();
        List<string> gliststRemainingBlackCities = new List<string>();
        List<string> gliststRemainingRedCities = new List<string>();

        List<string> gliststOwnedBlueCities = new List<string>();
        List<string> gliststOwnedYellowCities = new List<string>();
        List<string> gliststOwnedBlackCities = new List<string>();
        List<string> gliststOwnedRedCities = new List<string>();

        List<string> gliststDiscardedBlueCities = new List<string>();
        List<string> gliststDiscardedYellowCities = new List<string>();
        List<string> gliststDiscardedBlackCities = new List<string>();
        List<string> gliststDiscardedRedCities = new List<string>();               
        //------------------------------
        //------------------------------
        #endregion ..... Global Constants (#define) & Descriptors
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
        #region ..... Constructor / Destructor
        //------------------------------
        public dlgRemaining(List<string> liststRemainingBlueCities,
                                            List<string> liststRemainingYellowCities,
                                            List<string> liststRemainingBlackCities,
                                            List<string> liststRemainingRedCities,
                                            List<string> liststOwnedBlueCities,
                                            List<string> liststOwnedYellowCities,
                                            List<string> liststOwnedBlackCities,
                                            List<string> liststOwnedRedCities,
                                            List<string> liststDiscardedBlueCities,
                                            List<string> liststDiscardedYellowCities,
                                            List<string> liststDiscardedBlackCities,
                                            List<string> liststDiscardedRedCities)
        {
            InitializeComponent();
            gliststRemainingBlueCities = liststRemainingBlueCities;
            gliststRemainingYellowCities = liststRemainingYellowCities;
            gliststRemainingBlackCities = liststRemainingBlackCities;
            gliststRemainingRedCities = liststRemainingRedCities;

            gliststOwnedBlueCities = liststOwnedBlueCities;
            gliststOwnedYellowCities = liststOwnedYellowCities;
            gliststOwnedBlackCities = liststOwnedBlackCities;
            gliststOwnedRedCities = liststOwnedRedCities;

            gliststDiscardedBlueCities = liststDiscardedBlueCities;
            gliststDiscardedYellowCities = liststDiscardedYellowCities;
            gliststDiscardedBlackCities = liststDiscardedBlackCities;
            gliststDiscardedRedCities = liststDiscardedRedCities;
        }//MainWindow
        //------------------------------
        //------------------------------
        private void Window_ContentRendered(object sender, RoutedEventArgs e)
        {
            gRBuDiscardedCities.IsChecked = true;
            gRBuOwnedCities.IsChecked = false;
            FillListBoxes();
        }//Window_ContentRendered
        //------------------------------
        //------------------------------
        private void gBuReturn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }//gBuReturn_Click
        //------------------------------
        //------------------------------
        #endregion ..... Constructor / Destructor
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
        #region ..... Buttons / Mouse ... Cities / Infected
        //------------------------------
        //------------------------------
        private void gLBxRemainingBlueCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (gRBuDiscardedCities.IsChecked == true) 
                MoveFromListBoxListStringToListString(gLBxRemainingBlueCities, gliststRemainingBlueCities, gliststDiscardedBlueCities);
            else
                MoveFromListBoxListStringToListString(gLBxRemainingBlueCities, gliststRemainingBlueCities, gliststOwnedBlueCities);
        }//gLBxRemainingBlueCities_MouseDoubleClick
        //------------------------------
        //------------------------------
        private void gLBxOwnedAndDiscardedBlueCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (gRBuDiscardedCities.IsChecked == true)
                MoveFromListBoxListStringToListString(gLBxOwnedAndDiscardedBlueCities, gliststDiscardedBlueCities, gliststRemainingBlueCities);
            else
                MoveFromListBoxListStringToListString(gLBxOwnedAndDiscardedBlueCities, gliststOwnedBlueCities, gliststRemainingBlueCities);
        }//gLBxOwnedAndDiscardedBlueCities_MouseDoubleClick
        //------------------------------
        //------------------------------
        private void gLBxRemainingYellowCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (gRBuDiscardedCities.IsChecked == true)
                MoveFromListBoxListStringToListString(gLBxRemainingYellowCities, gliststRemainingYellowCities, gliststDiscardedYellowCities);
            else
                MoveFromListBoxListStringToListString(gLBxRemainingYellowCities, gliststRemainingYellowCities, gliststOwnedYellowCities);
        }//gLBxRemainingYellowCities_MouseDoubleClick
        //------------------------------
        //------------------------------
        private void gLBxOwnedAndDiscardedYellowCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (gRBuDiscardedCities.IsChecked == true)
                MoveFromListBoxListStringToListString(gLBxOwnedAndDiscardedYellowCities, gliststDiscardedYellowCities, gliststRemainingYellowCities);
            else
                MoveFromListBoxListStringToListString(gLBxOwnedAndDiscardedYellowCities, gliststOwnedYellowCities, gliststRemainingYellowCities);
        }//gLBxOwnedAndDiscardedYellowCities_MouseDoubleClick
        //------------------------------
        //------------------------------
        private void gLBxRemainingBlackCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (gRBuDiscardedCities.IsChecked == true)
                MoveFromListBoxListStringToListString(gLBxRemainingBlackCities, gliststRemainingBlackCities, gliststDiscardedBlackCities);
            else
                MoveFromListBoxListStringToListString(gLBxRemainingBlackCities, gliststRemainingBlackCities, gliststOwnedBlackCities);
        }//gLBxRemainingBlackCities_MouseDoubleClick
        //------------------------------
        //------------------------------
        private void gLBxOwnedAndDiscardedBlackCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (gRBuDiscardedCities.IsChecked == true)
                MoveFromListBoxListStringToListString(gLBxOwnedAndDiscardedBlackCities, gliststDiscardedBlackCities, gliststRemainingBlackCities);
            else
                MoveFromListBoxListStringToListString(gLBxOwnedAndDiscardedBlackCities, gliststOwnedBlackCities, gliststRemainingBlackCities);
        }//gLBxOwnedAndDiscardedBlackCities_MouseDoubleClick
        //------------------------------
        //------------------------------
        private void gLBxRemainingRedCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (gRBuDiscardedCities.IsChecked == true)
                MoveFromListBoxListStringToListString(gLBxRemainingRedCities, gliststRemainingRedCities, gliststDiscardedRedCities);
            else
                MoveFromListBoxListStringToListString(gLBxRemainingRedCities, gliststRemainingRedCities, gliststOwnedRedCities);
        }//gLBxRemainingRedCities_MouseDoubleClick
        //------------------------------
        //------------------------------
        private void gLBxOwnedAndDiscardedRedCities_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (gRBuDiscardedCities.IsChecked == true)
                MoveFromListBoxListStringToListString(gLBxOwnedAndDiscardedRedCities, gliststDiscardedRedCities, gliststRemainingRedCities);
            else
                MoveFromListBoxListStringToListString(gLBxOwnedAndDiscardedRedCities, gliststOwnedRedCities, gliststRemainingRedCities);
        }//gLBxOwnedAndDiscardedRedCities_MouseDoubleClick
        //------------------------------
        //------------------------------
        private void MoveFromListBoxListStringToListString(ListBox LBx, List<string> ListstFrom, List<string> ListstTo)
        {
            var selectedCity = LBx.SelectedItem;
            if (selectedCity != null) {
                int iIndex = -1;
                if (boRetrieveListBoxIndex(LBx, ref iIndex)) {
                    ListstTo.Add(ListstFrom[iIndex]);
                    ListstFrom.RemoveAt(iIndex);
                    FillListBoxes();
                }
            }
        }//MoveFromListBoxListStringToListString
        //------------------------------
        //------------------------------
        #endregion ..... Buttons / Mouse ... Cities / Infected
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
        #region ..... Radio Buttons
        //------------------------------
        //------------------------------
        private void gRBuDiscardedCities_Click(object sender, RoutedEventArgs e)
        {
            gRBuDiscardedCities.IsChecked = true;
            gRBuOwnedCities.IsChecked = false;
            FillListBoxes();
        }//gRBuDiscardedCities_Click
        //------------------------------
        //------------------------------
        private void gRBuOwnedCities_Click(object sender, RoutedEventArgs e)
        {
            gRBuDiscardedCities.IsChecked = false;
            gRBuOwnedCities.IsChecked = true;
            FillListBoxes();
        }//gRBuOwnedCities_Click
        //------------------------------
        //------------------------------
        #endregion ..... Radio Buttons
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
        #region ..... List Boxes
        //------------------------------
        //------------------------------
        public void FillListBoxes()
        {
            gliststRemainingBlueCities.Sort();
            gliststRemainingYellowCities.Sort();
            gliststRemainingBlackCities.Sort();
            gliststRemainingRedCities.Sort();

            gliststDiscardedBlueCities.Sort();
            gliststDiscardedYellowCities.Sort();
            gliststDiscardedBlackCities.Sort();
            gliststDiscardedRedCities.Sort();

            FillListBox(gLBxRemainingBlueCities, gliststRemainingBlueCities);
            FillListBox(gLBxRemainingYellowCities, gliststRemainingYellowCities);
            FillListBox(gLBxRemainingBlackCities, gliststRemainingBlackCities);
            FillListBox(gLBxRemainingRedCities, gliststRemainingRedCities);

            if (gRBuDiscardedCities.IsChecked == true) {
                FillListBox(gLBxOwnedAndDiscardedBlueCities, gliststDiscardedBlueCities);
                FillListBox(gLBxOwnedAndDiscardedYellowCities, gliststDiscardedYellowCities);
                FillListBox(gLBxOwnedAndDiscardedBlackCities, gliststDiscardedBlackCities);
                FillListBox(gLBxOwnedAndDiscardedRedCities, gliststDiscardedRedCities);
            }
            else {
                FillListBox(gLBxOwnedAndDiscardedBlueCities, gliststOwnedBlueCities);
                FillListBox(gLBxOwnedAndDiscardedYellowCities, gliststOwnedYellowCities);
                FillListBox(gLBxOwnedAndDiscardedBlackCities, gliststOwnedBlackCities);
                FillListBox(gLBxOwnedAndDiscardedRedCities, gliststOwnedRedCities);
            }

            if (gliststRemainingBlueCities.Count() == 0)
                this.gLBxOwnedAndDiscardedBlueCities.Visibility = System.Windows.Visibility.Collapsed;
            else
                this.gLBxOwnedAndDiscardedBlueCities.Visibility = System.Windows.Visibility.Visible;

            if (gliststRemainingYellowCities.Count() == 0)
                this.gLBxOwnedAndDiscardedYellowCities.Visibility = System.Windows.Visibility.Collapsed;
            else
                this.gLBxOwnedAndDiscardedYellowCities.Visibility = System.Windows.Visibility.Visible;
            
            if (gliststRemainingBlackCities.Count() == 0)
                this.gLBxOwnedAndDiscardedBlackCities.Visibility = System.Windows.Visibility.Collapsed;
            else
                this.gLBxOwnedAndDiscardedBlackCities.Visibility = System.Windows.Visibility.Visible;
            
            if (gliststRemainingRedCities.Count() == 0)
                this.gLBxOwnedAndDiscardedRedCities.Visibility = System.Windows.Visibility.Collapsed;
            else
                this.gLBxOwnedAndDiscardedRedCities.Visibility = System.Windows.Visibility.Visible;
        }//FillListBoxes
        //------------------------------
        //------------------------------
        public void FillListBox(ListBox LBx, List<string> ListSt)
        {
            LBx.Items.Clear();
            if (ListSt.Count > 0) {
                string stName = ListSt[0];
                LBx.Items.Add(stName);
                for (int iii = 1; iii < ListSt.Count; iii++) {
                    stName = ListSt[iii];
                    LBx.Items.Add(stName);
                }
            }
        }//FillListBox
        //------------------------------
        //------------------------------
        public bool boRetrieveListBoxIndex(ListBox LBx, ref int iIndex)
        {
            bool boItemIsSelectedFlag = false;
            iIndex = LBx.SelectedIndex;
            if (iIndex >= 0)
                boItemIsSelectedFlag = true;
            return boItemIsSelectedFlag;
        }//boRetrieveListBoxIndex
         //------------------------------
         //------------------------------
        #endregion ..... List Boxes
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
        #region ..... General
        //------------------------------
        //------------------------------
        public void CopyListToList(List<string> FromList, List<string> ToList)
        {
            ToList.Clear();
            int iCount = FromList.Count;
            for (int ii = 0; ii < iCount; ii++) {
                ToList.Add(FromList[iCount - 1 - ii]);
            }
        }//CopyListToList
        //------------------------------
        //------------------------------
        #endregion ..... General
        //------------------------------
        //+++++++++++++++++++
        //------------------------------
    }//dlgRemaining : Window
}//PandemicGame
